﻿' This file is used by Code Analysis to maintain SuppressMessage
' attributes that are applied to this project.
' Project-level suppressions either have no target or are given
' a specific target and scoped to a namespace, type, member, etc.

<Assembly: CodeAnalysis.SuppressMessage("Globalization", "CA2101:Specify marshaling for P/Invoke string arguments", Justification:="<pendiente>", Scope:="member", Target:="~M:AutoCAD2acad.clsAPI.GetWindowText(System.IntPtr,System.Text.StringBuilder,System.Int32)~System.Int32")>
